"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g;
    return g = { next: verb(0), "throw": verb(1), "return": verb(2) }, typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (_) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var web_api_1 = require("@slack/web-api");
var AWS = __importStar(require("aws-sdk"));
var web = new web_api_1.WebClient(process.env.SLACK_API_TOKEN);
var ecs = new AWS.ECS({ region: 'ap-northeast-1' });
var DOCKER_IMAGE_PATH = process.env.DOCKER_IMAGE_PATH;
var CLUSTER_NAME = process.env.CLUSTER_NAME;
var TASK_NAME = 'task-for-cdktf';
var CONTAINER_NAME = 'container-for-cdktf';
var SERVICE_NAME = 'container-for-cdktf-servic';
var LAUNCH_TYPE = 'FARGATE';
var PORT_NUMBER = 9000;
var DESIRED_COUNT = 1;
exports.handler = function (event) { return __awaiter(void 0, void 0, void 0, function () {
    var decodeMessage, jsonDecodeMessage, actions, dockerImageTag, PortMapping, LogConfiguration, ContainerDefinition, RegisterTaskDefinitionRequest, AwsVpcConfiguration, NetworkConfiguration, UpdateServiceRequest, params;
    return __generator(this, function (_a) {
        switch (_a.label) {
            case 0:
                decodeMessage = decodeURIComponent(event.body).replace("payload=", "");
                jsonDecodeMessage = JSON.parse(JSON.parse(JSON.stringify(decodeMessage)));
                actions = jsonDecodeMessage.actions[0];
                dockerImageTag = actions.value;
                PortMapping = {
                    containerPort: PORT_NUMBER,
                    hostPort: PORT_NUMBER,
                    protocol: 'tcp'
                };
                LogConfiguration = {
                    logDriver: 'awslogs',
                    options: {
                        'awslogs-group': '/ecs/task-for-cdktf',
                        'awslogs-region': 'ap-northeast-1',
                        'awslogs-stream-prefix': 'ecs'
                    }
                };
                ContainerDefinition = {
                    name: CONTAINER_NAME,
                    image: DOCKER_IMAGE_PATH + ":" + dockerImageTag,
                    portMappings: [PortMapping],
                    logConfiguration: LogConfiguration
                };
                RegisterTaskDefinitionRequest = {
                    family: TASK_NAME,
                    taskRoleArn: 'arn:aws:iam::445682127642:role/ecsTaskRole_for_cdktf',
                    executionRoleArn: 'arn:aws:iam::445682127642:role/ecsTaskExecutionRole_for_cdktf',
                    networkMode: 'awsvpc',
                    containerDefinitions: [ContainerDefinition],
                    requiresCompatibilities: [LAUNCH_TYPE],
                    cpu: '256',
                    memory: '512'
                };
                AwsVpcConfiguration = {
                    subnets: ['', ''],
                    securityGroups: [''],
                    assignPublicIp: 'ENABLED'
                };
                NetworkConfiguration = {
                    awsvpcConfiguration: AwsVpcConfiguration
                };
                UpdateServiceRequest = {
                    cluster: CLUSTER_NAME,
                    service: SERVICE_NAME,
                    desiredCount: DESIRED_COUNT,
                    taskDefinition: TASK_NAME,
                    networkConfiguration: NetworkConfiguration
                };
                params = {
                    channel: process.env.SLACK_CHANNEL,
                    ts: jsonDecodeMessage.message_ts,
                    text: '',
                    attachments: [
                        {
                            'text': ''
                        }
                    ]
                };
                if (!(actions.name == 'Deploy')) return [3, 2];
                ecs.registerTaskDefinition(RegisterTaskDefinitionRequest, function (err, data) {
                    if (err)
                        console.log("\u30BF\u30B9\u30AF\u306E\u4F5C\u6210\u306B\u5931\u6557\u3057\u307E\u3057\u305F:" + JSON.stringify(err));
                    else
                        console.log("\u30BF\u30B9\u30AF\u306E\u4F5C\u6210\u306B\u6210\u529F\u3057\u307E\u3057\u305F:" + JSON.stringify(data));
                });
                return [4, ecs.updateService(UpdateServiceRequest, function (err, data) {
                        if (err)
                            console.log("\u30B5\u30FC\u30D3\u30B9\u306E\u66F4\u65B0\u306B\u5931\u6557\u3057\u307E\u3057\u305F:" + JSON.stringify(err));
                        else
                            console.log("\u30B5\u30FC\u30D3\u30B9\u306E\u66F4\u65B0\u306B\u6210\u529F\u3057\u307E\u3057\u305F:" + JSON.stringify(data));
                    }).promise()];
            case 1:
                _a.sent();
                params.attachments[0].text = 'イメージがアップされました';
                return [3, 3];
            case 2:
                params.attachments[0].text = 'キャンセルされました';
                _a.label = 3;
            case 3: return [4, web.chat.update(params).then(function (res) {
                    console.log("\u30A4\u30E1\u30FC\u30B8\u306E\u66F4\u65B0\u3092\u884C\u3044\u307E\u3057\u305F:" + JSON.stringify(res));
                }).catch(console.error)];
            case 4:
                _a.sent();
                return [2];
        }
    });
}); };
